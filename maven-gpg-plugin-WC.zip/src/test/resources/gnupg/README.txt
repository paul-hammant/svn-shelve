This provides a key with uid
  Maven GPG Plugin (TESTING KEY) <dev@maven.apache.org>
and the passphrase
  TEST
